// import { Link } from "react-router-dom";
// import '../components/Footer1.css';


// export function Footer1() {
//     return (
//         <>
//             <link
//                 rel="stylesheet"
//                 href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
//             <footer>
//                 <div className="foot1" style={{ boxShadow: "-2px -1px 5px white inset" }}>
//                     <div className="logo">
//                         <img src="logo.jpg" alt="" />
//                     </div>
//                     <div className="quick">
//                         <div className="footheading">
//                             <b><i>Quick Links</i></b>
//                         </div>
//                         <br/>
//                         <ul>
//                             <li><Link to='/'>Home</Link></li>
//                             <li><Link to='/about-us'>About Us</Link></li>
//                             <li><Link to='/services'>Services</Link></li>
//                             <li><Link to='/contact-us'>Contact Us</Link></li>
//                         </ul>
//                     </div>
//                     <div className="social">
//                         <div>
//                             <b className="findus footheading">
//                                 <i>Find us on</i>
//                             </b>
//                         </div>
//                         <br />
//                         <div className="sociallogo">
//                             <div>
//                                 <i className="fa fb">
//                                     <a href="https://www.facebook.com/cafecoffeeday/" target="_blank" rel="noreferrer"></a>
//                                 </i>
//                             </div>
//                             <br />
//                             <div>
//                                 <i className="fa insta">
//                                     <a href="https://l.facebook.com/l.php?u=https%3A%2F%2Fwww.instagram.com%2Fcafecoffeeday&h=AT3rkwBtvnlXigpvqC-uu0QHuD0JFosFnGO9CJuYRTh2WMp_oN2gTpDHL9uiimtQ-yWRG_gpO270ugpCQxaQ-9dnlVmRszeI-VfydCLJ4XsFbkPpoEhvsz_Mh1wIhECs2Jr4CQGytXGRiCfUn58ruvI1oQOtXFX8In6hiw" target="_blank" rel="noreferrer">{" "}</a>
//                                 </i>
//                             </div>
//                             <br />
//                             <div>
//                                 <i className="fa yt">
//                                     <a href="https://www.youtube.com/user/cafecoffeeday" target="_blank" rel="noreferrer">{" "}</a>
//                                 </i>
//                             </div>
//                             <br />
//                         </div>
//                     </div>
//                     <div className="loc">
//                         <div>
//                             <b className="bclass footheading">
//                                 <i>Our Location</i>
//                             </b>
//                         </div>
//                         <br />
//                         <div>
//                             <i className="fa">&nbsp;</i> Cafe Coffee Day, Devaraj Urs Road, Mysore City
//                             <br />
//                             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
//                         </div>
//                         <div>
//                             <i className="fa">&nbsp;</i> 020 26362222 | 67292345
//                         </div>
//                         <div>
//                             <i className="fa">&nbsp;</i>{" "}
//                             <a href="mailto:cafecoffeday@gmail.com">
//                             carrentalsystem@gmail.com 
//                             </a>{" "}
//                         </div>
//                         <br />{" "}
//                     </div>
//                 </div>
//                 <div className="foot2">
//                     <div>RentSelf © 2023. All Rights Reserved.</div>
//                 </div>
//             </footer>
//         </>
//     );
// }